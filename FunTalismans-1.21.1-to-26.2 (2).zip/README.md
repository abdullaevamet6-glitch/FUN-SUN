# FunTalismans Resource Pack

## Supported Java Editions
- 1.21.1 through 1.21.3: legacy Custom Model Data overrides.
- 1.21.4 through 1.21.5: item definitions through `overlay_1_21_4_to_5`.
- 1.21.6 through 1.21.11: item definitions through `overlay_1_21_6_plus`.
- 26.1 and 26.2: item definitions through `overlay_1_21_6_plus` (resource-pack formats through 88).

The metadata keeps the compatibility bridge required by old pack formats while also declaring the modern `min_format` / `max_format` range used by newer Minecraft versions.

## Custom Model Data
- 101: talisman_darkness
- 102: talisman_demonic
- 103: talisman_vortex
- 104: talisman_discord
- 105: talisman_tyrant
- 106: talisman_fury
- 107: talisman_crusher
- 108: talisman_punisher

The talisman display transforms preserve the supplied reference behavior: 0.40 scale in first person, 0.55 in third person and 0.50 on the ground, plus enlarged modern GUI rendering.

## Bedrock / Geyser
Bedrock support is distributed separately because Bedrock cannot load Java resource packs. Use the included Bedrock `.mcpack` plus the Geyser custom-item mapping file.
